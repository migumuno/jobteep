<?php

return array(
	// Database name
	'database'  => 'imgpicker',
	
	// Database username
	'username'  => 'root',
	
	// Database password
	'password'  => '',

	//Database hostname
	'hostname'  => '127.0.0.1',

	// Advanced options
	'prefix'    => '',
	'driver'    => 'mysql',
	'charset'   => 'utf8',
	'collation' => 'utf8_unicode_ci',
);